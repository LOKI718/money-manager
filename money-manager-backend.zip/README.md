# Money Manager Backend

RESTful API for the Money Manager application built with Node.js, Express, and MongoDB.

## Features

- 📊 Transaction management (CRUD operations)
- 💳 Account management
- 🔄 Fund transfers between accounts
- 📈 Dashboard statistics and analytics
- 🔍 Advanced filtering and querying
- ⏱️ 12-hour edit restriction for transactions
- 📅 Date range filtering

## Technologies Used

- Node.js
- Express.js
- MongoDB with Mongoose
- CORS
- Morgan (logging)
- dotenv (environment variables)

## Prerequisites

- Node.js (v14 or higher)
- MongoDB Atlas account or local MongoDB installation
- npm or yarn

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd money-manager-backend
```

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file in the root directory:
```bash
cp .env.example .env
```

4. Update the `.env` file with your MongoDB connection string:
```
PORT=5000
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/money-manager?retryWrites=true&w=majority
NODE_ENV=development
```

## MongoDB Atlas Setup

1. Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
2. Create a free cluster
3. Create a database user
4. Whitelist your IP address (or use 0.0.0.0/0 for all IPs)
5. Get your connection string and update MONGODB_URI in .env

## Running the Application

### Development Mode (with auto-restart)

```bash
npm run dev
```

### Production Mode

```bash
npm start
```

The server will start on `http://localhost:5000`

## API Endpoints

### Health Check
- `GET /health` - Check server status

### Transactions
- `GET /api/transactions` - Get all transactions (supports filtering)
- `GET /api/transactions/:id` - Get single transaction
- `POST /api/transactions` - Create new transaction
- `PUT /api/transactions/:id` - Update transaction (within 12 hours)
- `DELETE /api/transactions/:id` - Delete transaction

**Query Parameters for GET /api/transactions:**
- `type` - Filter by income/expense
- `category` - Filter by category
- `division` - Filter by Personal/Office
- `startDate` - Start date for date range
- `endDate` - End date for date range
- `account` - Filter by account ID

### Accounts
- `GET /api/accounts` - Get all accounts
- `GET /api/accounts/:id` - Get single account
- `POST /api/accounts` - Create new account
- `PUT /api/accounts/:id` - Update account
- `DELETE /api/accounts/:id` - Delete account
- `POST /api/accounts/transfer` - Transfer funds between accounts

### Dashboard
- `GET /api/dashboard/stats` - Get dashboard statistics
  - Query params: `startDate`, `endDate`
- `GET /api/dashboard/monthly-summary` - Get monthly summary
  - Query params: `year`

## Request/Response Examples

### Create Transaction
```json
POST /api/transactions
{
  "type": "expense",
  "amount": 50.00,
  "category": "Food",
  "description": "Lunch at restaurant",
  "division": "Personal",
  "account": "account_id_here",
  "date": "2024-01-30T12:00:00Z"
}
```

### Create Account
```json
POST /api/accounts
{
  "name": "Savings Account",
  "balance": 1000.00
}
```

### Transfer Funds
```json
POST /api/accounts/transfer
{
  "from": "from_account_id",
  "to": "to_account_id",
  "amount": 100.00
}
```

## Data Models

### Transaction
```javascript
{
  type: String (income/expense),
  amount: Number,
  category: String,
  description: String,
  division: String (Personal/Office),
  account: ObjectId (ref: Account),
  date: Date,
  createdAt: Date
}
```

### Account
```javascript
{
  name: String,
  balance: Number,
  createdAt: Date
}
```

## Error Handling

The API returns appropriate HTTP status codes:
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `403` - Forbidden (e.g., editing after 12 hours)
- `404` - Not Found
- `500` - Internal Server Error

## Deployment

### Deploy to Render

1. Create account on [Render](https://render.com)
2. Create new Web Service
3. Connect your GitHub repository
4. Configure:
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Add environment variables (MONGODB_URI, NODE_ENV)
5. Deploy

### Deploy to Railway

1. Create account on [Railway](https://railway.app)
2. Create new project
3. Connect GitHub repository
4. Add environment variables
5. Deploy

### Deploy to Heroku

1. Install Heroku CLI
2. Login: `heroku login`
3. Create app: `heroku create your-app-name`
4. Set environment variables:
```bash
heroku config:set MONGODB_URI=your_mongodb_uri
heroku config:set NODE_ENV=production
```
5. Deploy:
```bash
git push heroku main
```

## Environment Variables

- `PORT` - Server port (default: 5000)
- `MONGODB_URI` - MongoDB connection string
- `NODE_ENV` - Environment (development/production)

## Security Notes

- Always use environment variables for sensitive data
- Never commit .env file to version control
- Use HTTPS in production
- Implement rate limiting for production
- Add authentication/authorization as needed

## Testing

You can test the API using:
- Postman
- Thunder Client (VS Code extension)
- cURL
- Your frontend application

## Contributing

This is an open-source project. Feel free to contribute!

## License

MIT License
