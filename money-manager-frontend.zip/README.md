# Money Manager Frontend

A modern, responsive web application for managing personal finances built with React and Tailwind CSS.

## Features

- 📊 Dashboard with visual analytics (monthly, weekly, yearly)
- 💰 Income and expense tracking
- 📁 Category-based organization
- 🏢 Office and Personal divisions
- 🔍 Advanced filtering and search
- 📅 Date range filtering
- ✏️ Edit transactions within 12 hours
- 💳 Multiple account management
- 🔄 Account-to-account transfers
- 📈 Comprehensive charts and statistics

## Technologies Used

- React 18
- Tailwind CSS
- Recharts (for data visualization)
- Axios (for API calls)
- date-fns (for date handling)
- Lucide React (for icons)

## Prerequisites

- Node.js (v14 or higher)
- npm or yarn

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd money-manager-frontend
```

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file in the root directory:
```bash
cp .env.example .env
```

4. Update the `.env` file with your backend API URL:
```
REACT_APP_API_URL=http://localhost:5000/api
```

## Running the Application

### Development Mode

```bash
npm start
```

The application will open at [http://localhost:3000](http://localhost:3000)

### Build for Production

```bash
npm run build
```

This creates an optimized production build in the `build` folder.

## Project Structure

```
money-manager-frontend/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   ├── Dashboard.js
│   │   ├── TransactionHistory.js
│   │   ├── TransactionModal.js
│   │   └── Accounts.js
│   ├── services/
│   │   └── api.js
│   ├── App.js
│   ├── index.js
│   └── index.css
├── package.json
├── tailwind.config.js
└── README.md
```

## Features Description

### Dashboard
- View income vs expense comparison
- Category-wise expense breakdown
- Filter by weekly, monthly, or yearly data
- Visual charts using Recharts

### Transaction History
- Complete list of all transactions
- Filter by type, category, division, and date range
- Search functionality
- Edit/delete transactions (edit restricted to 12 hours)

### Accounts
- Manage multiple accounts
- View account balances
- Transfer funds between accounts

### Transaction Management
- Add income/expense with detailed information
- Categorize transactions
- Assign to Office or Personal division
- Track date and time

## Deployment

### Deploy to Vercel

1. Install Vercel CLI:
```bash
npm install -g vercel
```

2. Deploy:
```bash
vercel
```

### Deploy to Netlify

1. Build the project:
```bash
npm run build
```

2. Deploy the `build` folder to Netlify

### Deploy to Other Platforms

The application can be deployed to any static hosting service that supports React applications:
- GitHub Pages
- AWS S3 + CloudFront
- Firebase Hosting
- Render
- Railway

## Environment Variables

- `REACT_APP_API_URL`: Backend API URL (default: http://localhost:5000/api)

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Contributing

This is an open-source project. Feel free to contribute!

## License

MIT License
